export default function App() {
  return (
    <div style={{fontFamily: 'sans-serif', padding: '40px', textAlign: 'center'}}>
      <h1>🥛 Badamé</h1>
      <p>Rich • Nutty • Creamy</p>
      <p>🔥 Hot & ❄️ Cold Badam Milk Available</p>
      <p>Website setup successful.</p>
    </div>
  )
}